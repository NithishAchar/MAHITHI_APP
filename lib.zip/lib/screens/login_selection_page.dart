import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:animations/animations.dart';
import 'package:job/screens/home_page.dart';

class LoginSelectionPage extends StatefulWidget {
  const LoginSelectionPage({super.key});

  @override
  State<LoginSelectionPage> createState() => _LoginSelectionPageState();
}

class _LoginSelectionPageState extends State<LoginSelectionPage> {
  int _selectedOption = -1;
  bool _isLoading = false;

  void _showLoginDialog(BuildContext context, String type) {
    final formKey = GlobalKey<FormState>();
    String? id, email, password, name, regNumber;

    showModal(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.brown.withOpacity(0.1),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.brown.shade50,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  type == 'faculty'
                      ? Icons.school
                      : type == 'student'
                          ? Icons.person_outline
                          : Icons.public,
                  size: 40,
                  color: Colors.brown,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Welcome Back!',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.brown.shade800,
                ),
              ),
              Text(
                'Login as ${type.capitalize()}',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.brown.shade400,
                ),
              ),
              const SizedBox(height: 24),
              Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (type == 'faculty') ...[
                      _buildTextField(
                        label: 'Faculty ID',
                        onSaved: (value) => id = value,
                        validator: (value) => value?.isEmpty ?? true
                            ? 'Please enter Faculty ID'
                            : null,
                      ),
                      const SizedBox(height: 16),
                      _buildTextField(
                        label: 'Email',
                        onSaved: (value) => email = value,
                        validator: (value) =>
                            !value!.contains('@') ? 'Invalid email' : null,
                      ),
                    ] else if (type == 'student') ...[
                      _buildTextField(
                        label: 'Registration Number',
                        onSaved: (value) => regNumber = value,
                        validator: (value) => value?.isEmpty ?? true
                            ? 'Please enter Registration Number'
                            : null,
                      ),
                    ] else ...[
                      _buildTextField(
                        label: 'Name',
                        onSaved: (value) => name = value,
                        validator: (value) => value?.isEmpty ?? true
                            ? 'Please enter your name'
                            : null,
                      ),
                      const SizedBox(height: 16),
                      _buildTextField(
                        label: 'Email',
                        onSaved: (value) => email = value,
                        validator: (value) =>
                            !value!.contains('@') ? 'Invalid email' : null,
                      ),
                    ],
                    const SizedBox(height: 16),
                    _buildTextField(
                      label: 'Password',
                      isPassword: true,
                      onSaved: (value) => password = value,
                      validator: (value) => (value?.length ?? 0) < 6
                          ? 'Password too short'
                          : null,
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.brown,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          elevation: 0,
                        ),
                        onPressed: () async {
                          if (formKey.currentState?.validate() ?? false) {
                            formKey.currentState?.save();
                            setState(() => _isLoading = true);

                            final prefs = await SharedPreferences.getInstance();
                            final userData = {
                              'type': type,
                              if (id != null) 'id': id,
                              if (email != null) 'email': email,
                              if (name != null) 'name': name,
                              if (regNumber != null) 'regNumber': regNumber,
                            };
                            await prefs.setString(
                              'userData',
                              json.encode(userData),
                            );

                            setState(() => _isLoading = false);
                            if (context.mounted) {
                              Navigator.pushReplacement(
                                context,
                                PageRouteBuilder(
                                  pageBuilder: (
                                    context,
                                    animation,
                                    secondaryAnimation,
                                  ) =>
                                      const HomePage(),
                                  transitionsBuilder: (
                                    context,
                                    animation,
                                    secondaryAnimation,
                                    child,
                                  ) {
                                    return SharedAxisTransition(
                                      animation: animation,
                                      secondaryAnimation: secondaryAnimation,
                                      transitionType:
                                          SharedAxisTransitionType.scaled,
                                      child: child,
                                    );
                                  },
                                ),
                              );
                            }
                          }
                        },
                        child: _isLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.white,
                                  ),
                                  strokeWidth: 2,
                                ),
                              )
                            : Text(
                                type == 'public' ? 'Sign Up' : 'Login',
                              ),
                      ),
                    ),
                    if (type == 'faculty') ...[
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Don't have an account?",
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.brown.shade400,
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context); // Close dialog
                              Navigator.pushNamed(context, '/faculty-register');
                            },
                            child: const Text(
                              'Register',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.brown,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    bool isPassword = false,
    required FormFieldValidator<String> validator,
    required FormFieldSetter<String> onSaved,
  }) {
    return TextFormField(
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.brown.shade50,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
        prefixIcon: Icon(
          isPassword
              ? Icons.lock_outline
              : label.contains('Email')
                  ? Icons.email_outlined
                  : label.contains('ID') || label.contains('Number')
                      ? Icons.badge_outlined
                      : Icons.person_outline,
          color: Colors.brown,
        ),
        suffixIcon: isPassword
            ? Icon(Icons.visibility_outlined, color: Colors.brown.shade300)
            : null,
        labelStyle: TextStyle(color: Colors.brown.shade400),
      ),
      style: const TextStyle(color: Colors.brown),
      obscureText: isPassword,
      validator: validator,
      onSaved: onSaved,
    );
  }

  Widget _buildLoginOption(String type, IconData icon, int index) {
    final isSelected = _selectedOption == index;
    return GestureDetector(
      onTap: () {
        if (type == 'student') {
          Navigator.pushNamed(context, '/student-login');
        } else if (type == 'public') {
          Navigator.pushNamed(context, '/student-register');
        } else {
          setState(() => _selectedOption = index);
          _showLoginDialog(context, type);
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: isSelected ? Colors.brown.shade50 : Colors.white,
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: isSelected ? Colors.brown : Colors.brown.shade200,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.brown.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color:
                    isSelected ? Colors.brown.shade100 : Colors.brown.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: Colors.brown, size: 28),
            ),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${type.capitalize()} Login',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                    color: Colors.brown.shade800,
                  ),
                ),
                Text(
                  type == 'public'
                      ? 'Create new account'
                      : 'Access your account',
                  style: TextStyle(fontSize: 12, color: Colors.brown.shade400),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown.shade50,
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: -100,
              right: -100,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  color: Colors.brown.shade100,
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              bottom: -150,
              left: -150,
              child: Container(
                width: 400,
                height: 400,
                decoration: BoxDecoration(
                  color: Colors.brown.shade100,
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.brown.shade100,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          '👋 Welcome back',
                          style: TextStyle(fontSize: 16, color: Colors.brown),
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'MAHITHI',
                        style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          color: Colors.brown,
                        ),
                      ),
                      Text(
                        'Choose your login type to continue',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.brown.shade400,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 40),
                _buildLoginOption('faculty', Icons.school, 0),
                _buildLoginOption('student', Icons.person_outline, 1),
                _buildLoginOption('public', Icons.public, 2),
                const Spacer(),
                Center(
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 20),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.brown.shade200),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.shield,
                          size: 16,
                          color: Colors.brown.shade400,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Secure Login',
                          style: TextStyle(
                            color: Colors.brown.shade400,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1).toLowerCase()}";
  }
}
